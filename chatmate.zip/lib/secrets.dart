// WARNING: Storing secrets in client apps exposes them to users.
// You asked to proceed — adding your OpenRouter API key here.

// Provided by user (trimmed of spaces/newlines). If key changes, update here.
const String openRouterApiKey =
    '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';

// Model specified by user.
const String openRouterModel = 'z-ai/glm-4.5-air:free';
